from flask import Flask, render_template, request, jsonify
import sqlite3
from pathlib import Path
from datetime import datetime, date

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / 'aurora_drive.db'
app = Flask(__name__)
app.config['JSON_SORT_KEYS'] = False

SEED_CARS = [
    {'name':'Mercedes-Benz C-Class','category':'LUXURY SEDAN','price':5499,'seats':5,'transmission':'Automatic','fuel':'Petrol','range':'City elegance','image':'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?auto=format&fit=crop&w=1200&q=85','tag':'SIGNATURE','accent':'silver'},
    {'name':'BMW 3 Series','category':'SPORT SEDAN','price':4999,'seats':5,'transmission':'Automatic','fuel':'Petrol','range':'Made for the drive','image':'https://images.unsplash.com/photo-1555215695-3004980ad54e?auto=format&fit=crop&w=1200&q=85','tag':'POPULAR','accent':'blue'},
    {'name':'Range Rover Evoque','category':'PREMIUM SUV','price':6999,'seats':5,'transmission':'Automatic','fuel':'Diesel','range':'Go beyond ordinary','image':'https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?auto=format&fit=crop&w=1200&q=85','tag':'ADVENTURE','accent':'black'},
    {'name':'Porsche 911 Carrera','category':'PERFORMANCE','price':14999,'seats':2,'transmission':'Automatic','fuel':'Petrol','range':'An unforgettable escape','image':'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=85','tag':'EXCLUSIVE','accent':'red'},
    {'name':'Tesla Model 3','category':'ELECTRIC','price':5999,'seats':5,'transmission':'Automatic','fuel':'Electric','range':'A quieter kind of power','image':'https://images.unsplash.com/photo-1560958089-b8a1929cea89?auto=format&fit=crop&w=1200&q=85','tag':'ELECTRIC','accent':'white'},
    {'name':'Toyota Fortuner','category':'FULL-SIZE SUV','price':6499,'seats':7,'transmission':'Automatic','fuel':'Diesel','range':'Room for every story','image':'https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?auto=format&fit=crop&w=1200&q=85','tag':'FAMILY PICK','accent':'dark'},
]

def connect_db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with connect_db() as con:
        con.execute('''CREATE TABLE IF NOT EXISTS cars (
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT NOT NULL,
            price INTEGER NOT NULL, seats INTEGER NOT NULL, transmission TEXT NOT NULL,
            fuel TEXT NOT NULL, range_text TEXT NOT NULL, image TEXT NOT NULL, tag TEXT NOT NULL,
            accent TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1)''')
        con.execute('''CREATE TABLE IF NOT EXISTS bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT, booking_code TEXT UNIQUE NOT NULL,
            car_id INTEGER NOT NULL, customer_name TEXT NOT NULL, email TEXT NOT NULL,
            phone TEXT NOT NULL, pickup_location TEXT NOT NULL, pickup_date TEXT NOT NULL,
            return_date TEXT NOT NULL, total_days INTEGER NOT NULL, total_price INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT 'Confirmed', created_at TEXT NOT NULL,
            FOREIGN KEY(car_id) REFERENCES cars(id))''')
        count = con.execute('SELECT COUNT(*) FROM cars').fetchone()[0]
        if count == 0:
            for car in SEED_CARS:
                con.execute('''INSERT INTO cars(name,category,price,seats,transmission,fuel,range_text,image,tag,accent)
                    VALUES(?,?,?,?,?,?,?,?,?,?)''', (car['name'], car['category'], car['price'], car['seats'], car['transmission'], car['fuel'], car['range'], car['image'], car['tag'], car['accent']))

def row_to_car(row):
    return {'id':row['id'],'name':row['name'],'category':row['category'],'price':row['price'],'seats':row['seats'],
            'transmission':row['transmission'],'fuel':row['fuel'],'range':row['range_text'],'image':row['image'],
            'tag':row['tag'],'accent':row['accent']}

@app.route('/')
def home():
    return render_template('index.html')

@app.get('/api/cars')
def cars():
    with connect_db() as con:
        rows = con.execute('SELECT * FROM cars WHERE active=1 ORDER BY price').fetchall()
        return jsonify([row_to_car(r) for r in rows])

@app.post('/api/bookings')
def create_booking():
    data = request.get_json(silent=True) or {}
    required = ['car_id','customer_name','email','phone','pickup_location','pickup_date','return_date']
    missing = [k for k in required if not str(data.get(k, '')).strip()]
    if missing:
        return jsonify({'error':'Please complete all required fields.','fields':missing}), 400
    try:
        car_id = int(data['car_id'])
        pickup = date.fromisoformat(data['pickup_date'])
        returned = date.fromisoformat(data['return_date'])
    except (ValueError, TypeError):
        return jsonify({'error':'Please enter a valid car and dates.'}), 400
    today = date.today()
    if pickup < today:
        return jsonify({'error':'Pickup date cannot be in the past.'}), 400
    if returned <= pickup:
        return jsonify({'error':'Return date must be after the pickup date.'}), 400
    days = (returned - pickup).days
    with connect_db() as con:
        car = con.execute('SELECT * FROM cars WHERE id=? AND active=1', (car_id,)).fetchone()
        if not car:
            return jsonify({'error':'That car is no longer available.'}), 404
        overlap = con.execute('''SELECT COUNT(*) FROM bookings WHERE car_id=? AND status='Confirmed'
            AND pickup_date < ? AND return_date > ?''', (car_id, returned.isoformat(), pickup.isoformat())).fetchone()[0]
        if overlap:
            return jsonify({'error':'This car is already booked for some or all of those dates. Please choose another date or car.'}), 409
        total = days * car['price']
        code = 'AD-' + datetime.now().strftime('%y%m%d') + '-' + str(int(datetime.now().timestamp()))[-6:]
        con.execute('''INSERT INTO bookings(booking_code,car_id,customer_name,email,phone,pickup_location,pickup_date,return_date,total_days,total_price,status,created_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''', (code, car_id, data['customer_name'].strip(), data['email'].strip(), data['phone'].strip(), data['pickup_location'].strip(), pickup.isoformat(), returned.isoformat(), days, total, 'Confirmed', datetime.now().isoformat(timespec='seconds')))
        return jsonify({'message':'Your booking is confirmed.','booking':{'code':code,'car':car['name'],'customer':data['customer_name'].strip(),'pickup_date':pickup.isoformat(),'return_date':returned.isoformat(),'days':days,'total':total,'location':data['pickup_location'].strip(),'status':'Confirmed'}}), 201

@app.get('/api/admin/summary')
def admin_summary():
    # Demo-only dashboard endpoint. Add authentication before public deployment.
    with connect_db() as con:
        total = con.execute('SELECT COUNT(*) FROM bookings').fetchone()[0]
        confirmed = con.execute("SELECT COUNT(*) FROM bookings WHERE status='Confirmed'").fetchone()[0]
        revenue = con.execute("SELECT COALESCE(SUM(total_price),0) FROM bookings WHERE status='Confirmed'").fetchone()[0]
        recent = con.execute('''SELECT b.booking_code,b.customer_name,b.pickup_date,b.return_date,b.total_price,b.status,c.name AS car_name
            FROM bookings b JOIN cars c ON c.id=b.car_id ORDER BY b.id DESC LIMIT 8''').fetchall()
        return jsonify({'total_bookings':total,'confirmed_bookings':confirmed,'revenue':revenue,'recent':[dict(r) for r in recent]})

@app.post('/api/concierge')
def concierge():
    data = request.get_json(silent=True) or {}
    message = str(data.get('message','')).lower()
    with connect_db() as con:
        cars = con.execute('SELECT name,category,price,seats,fuel FROM cars WHERE active=1 ORDER BY price').fetchall()
    if any(word in message for word in ['family','kids','7 seat','seven seat','group']):
        matches = [c for c in cars if c['seats'] >= 7]
        intro = 'For family trips and extra room, I would start with the Toyota Fortuner.'
    elif any(word in message for word in ['electric','ev','eco','environment']):
        matches = [c for c in cars if c['fuel'].lower() == 'electric']
        intro = 'For an electric drive, the Tesla Model 3 is the best match in our current fleet.'
    elif any(word in message for word in ['cheap','budget','affordable','under','low price']):
        matches = [c for c in cars if c['price'] <= 5500]
        intro = 'For a more budget-conscious premium ride, these are good places to start.'
    elif any(word in message for word in ['sport','fast','performance','special','date']):
        matches = [c for c in cars if c['category'] in ('PERFORMANCE','LUXURY SEDAN','SPORT SEDAN')]
        intro = 'For a memorable drive, consider one of these performance or premium options.'
    else:
        matches = [c for c in cars[:3]]
        intro = 'Tell me your budget, passenger count, or trip style and I can narrow it down. Here are a few popular options.'
    return jsonify({'reply':intro,'recommendations':[{'name':c['name'],'price':c['price'],'category':c['category']} for c in matches[:3]]})

init_db()

if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=5000)
